from django.shortcuts import render
from . import kroger_apis as kroger
from .models import *


def show_products(request):
    if request.method == "POST":
        zip_code = request.POST.get("zip")
        query = request.POST.get("query")
        access_token = kroger.connect()
        locations = kroger.getLocations(access_token, zip_code)
        products = kroger.getProductsData(access_token, query, locations)
        for product in products:
            _product, created = Product.objects.get_or_create(product_id=product["product_id"], loc_name=product["loc_name"])
            print(_product.product_id, " created : ", created)
            _product.size = product["size"]
            _product.price = product["price"]
            _product.in_store = product["in_store"]
            _product.loc_address = product["loc_address"]
            _product.save()

    else:
        zip_code = ""
        query = ""
        products = []

    context = {
        "zip_code": zip_code,
        "query": query,
        "products": products
    }

    return render(request, "home/index.html", context=context)