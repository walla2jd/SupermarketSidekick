#!/usr/bin/python
# -*- coding: utf-8 -*-

import requests
import base64
import pandas as pd
from sqlalchemy import create_engine
import environ

env = environ.Env()
environ.Env.read_env()

KROGER_ID = env("CLIENT_ID")
KROGER_SECRET = env("CLIENT_SECRET")


def encode_str(str1):
    message_bytes = str1.encode('utf-8')
    base64_bytes = base64.b64encode(message_bytes)
    base64_message = base64_bytes.decode('utf-8')
    return base64_message


def get_access_token(client_id, client_secret):
    sec1 = encode_str(client_id + ":" + client_secret)

    header = {"Authorization": "Basic " + sec1,
              "Content-Type": "application/x-www-form-urlencoded"}

    params = {"grant_type": "client_credentials",
              "scope": "product.compact"
              }

    url = "https://api.kroger.com/v1/connect/oauth2/token"
    access_token = requests.post(url, headers=header, params=params).json()['access_token']

    return access_token


def getLocations(access_token, zip_code):
    try:
        header = {"Authorization": "Bearer " + access_token,
                  "Accept": "application/json"
                  }

        params = {"filter.zipCode.near": zip_code,
                  "filter.limit": 200,
                  "filter.chain": 'KROGER'
                  }

        loction_url = "https://api.kroger.com/v1/locations"
        response = requests.get(loction_url, headers=header, params=params).json()
        if "data" in response.keys():
            response = response['data']
        else:
            response = []
    except:
        response = []

    return response


def searchProduct(access_token, search_query, loc_id, start_index):
    header = {"Authorization": "Bearer " + access_token,
              "Accept": "application/json"
              }

    params = {"filter.term": search_query,
              "filter.locationId": loc_id,
              "filter.start": start_index,
              "filter.limit": 5
              }
    prod_url = "https://api.kroger.com/v1/products"
    response = requests.get(prod_url, headers=header, params=params).json()
    if "data" in response.keys():
        response = response['data']
    else:
        response = []
    return response


def connect():
    access_token = get_access_token(KROGER_ID, KROGER_SECRET)
    return access_token


def _get_attr(object, *args):
    item = None
    try:

        for idx, arg in enumerate(args):
            if idx == 0:
                item = object[arg]
            else:
                item = item[arg]

        return item
    except:
        return None


def getProductsData(access_token, search_query, locations):
    max_res = 25
    max_res_reached = False
    data = []
    try:
        for loc in locations:
            prods = searchProduct(access_token, search_query, loc["locationId"], 1)
            if len(prods) != 0:
                for prod in prods:
                    product_price = _get_attr(prod, "items", 0, "price", "regular")
                    product_in_store = _get_attr(prod, "items", 0, "fulfillment", "inStore")
                    data_element = {"loc_name": _get_attr(loc, "name"),
                                    "loc_address": ', '.join(list(loc['address'].values())),
                                    "product_id": str(prod['productId']),
                                    "size": _get_attr(prod, "items", 0, 'size'),
                                    "price": float(product_price) if product_price is not None else None,
                                    "in_store": product_in_store
                                    }

                    data.append(data_element)

                    max_res -= 1
                    if max_res == 0:
                        max_res_reached = True

                    if max_res_reached:
                        break

            if max_res_reached:
                break
    except:
        pass

    return data


def _main():
    # zip for test 72801

    access_token = get_access_token(KROGER_ID, KROGER_SECRET)

    zip_code = input("Please Enter Zip Code \n>")

    search_query = input("Please Enter search query \n>")

    locations = getLocations(access_token, zip_code)

    max_res = 25
    max_res_reached = False
    for loc in locations:

        prods = searchProduct(access_token, search_query, loc["locationId"], 1)
        if len(prods) != 0:

            print("\n####  " + loc['name'] + ' ---- ' + ', '.join(list(loc['address'].values())))
            # df=pd.DataFrame([nm], columns=['name', 'address'])
            # df.to_sql(con=my_conn,name='kroger', if_exists='replace', index=False)

            for prod in prods:

                print("-ID: " + prod['productId'] + ' -SIZE: ' + prod["items"][0]['size'] + ' -PRICE: ' + str(
                    prod["items"][0]['price']['regular']) + '  -IN STORE:  ' + str(
                    prod["items"][0]['fulfillment']['inStore']))
                max_res -= 1
                if max_res == 0:
                    max_res_reached = True

                if max_res_reached:
                    break
        if max_res_reached:
            break


if __name__ == '__main__':
    _main()




