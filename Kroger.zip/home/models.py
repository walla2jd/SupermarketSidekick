from django.db import models

# Create your models here.


class Product(models.Model):
    product_id = models.CharField(max_length=14, null=False)
    size = models.CharField(max_length=100, null=True)
    price = models.FloatField(null=True)
    in_store = models.BooleanField(default=False)
    loc_name = models.CharField(max_length=255, default="")
    loc_address = models.CharField(max_length=255, default="")

    class Meta:
        unique_together = (('product_id', 'loc_name'),)
